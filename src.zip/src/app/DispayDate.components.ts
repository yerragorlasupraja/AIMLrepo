import { Component } from '@angular/core';

@Component({
    selector: "my-samp-date",
    template: ` <p >Date and time is {{result}} </p>`,
})

export class DisplayDate{
    result: string;

    constructor() {
        var d = new Date();
        this.result = d.toString();
    }
}